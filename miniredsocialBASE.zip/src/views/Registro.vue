<template>
  <div class="about">
    <h1>Registrar</h1>
    <FormularioRegistro />
  </div>
</template>

<script>
import FormularioRegistro from "../components/FormularioRegistro";
export default {
  name: "Login",
  components: {
    FormularioRegistro
  }
};
</script>
