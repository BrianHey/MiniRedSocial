<template>
  <div id="FormularioLogin">
    <form>
      <div class="form-group">
        <label for="exampleInputEmail1">Correlo electrónico</label>
        <input type="email" class="form-control" />
      </div>
      <div class="form-group">
        <label for="exampleInputPassword1">Contraseña</label>
        <input type="password" class="form-control" />
      </div>
      <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  </div>
</template>

<style  scoped>
#FormularioLogin {
  width: 40%;
  margin: auto;
  border: 1px solid;
  padding: 20px;
  border-radius: 15px;
}
</style>
