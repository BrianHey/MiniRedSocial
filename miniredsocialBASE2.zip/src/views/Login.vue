<template>
  <div class="about">
    <h1>Log in</h1>
    <FormularioLogin />
  </div>
</template>

<script>
import FormularioLogin from "../components/FormularioLogin";
export default {
  name: "Login",
  components: {
    FormularioLogin
  }
};
</script>
